//this homework
//Ex1

const date = {
  info: "dlkf",
  logInfo: function () {
    console.log(this.info);
  },
};
date.logInfo();
//Ex2
const user = {
  name: "avital",
  getName: function () {
    return this.name;
  },
};
console.log(user.getName());
//Ex3
const mail = {
  port: function () {
    return 225;
  },
  send: function () {
    return "Requset to port " + this.port();
  },
};
console.log(mail.send());
//Ex4
let $div = document.getElementById("content");
const date1 = {
  articles: ["a", "dfd", "fgfg"],
  print: function () {
    for (let i = 0; i < this.articles.lengthl; i++) {
      $div.innerHTML += "<p>" + this.articles[i] + "</p>";
    }
  },
};
//ex5
const ob = {
  name: null,
  getter: function () {
    return this.name;
  },
  setter: function (newName) {
    this.name = newName;
  },
};
let a = ob.setter("adf").getter();
console.log(a);

//Ex6
const product = {
  sizes: ["s", "m", "l", "xL"],
  print: function () {
    let a = document.getElementById("sizes");
    a.innerHTML += "<option>select size </option>";
    for (let i = 0; i < this.sizes.length; i++) {
      a.innerHTML += "<option>" + this.sizes[i] + "</option>";
    }
  },
};
product.print();

//Ex7
let prop = prompt("What you want to change").toLowerCase();
let val = prompt("what value to put in");
const person = {
  age: 24.2,
  name: "avital",
  childern: ["avishag,odel,,mordechai"],
  get: function (prop) {
    return this.prop;
  },
  set: function (prop, val) {
    this.prop = val;
    return this;
  },
};
console.log(person.set(prop, val).get(prop));
